// import 'package:flutter/material.dart';
// import 'package:qf/colors.dart';
// import 'package:qf/searchpage.dart';
//
// import 'cart_page_old.dart';
// import 'category_screen.dart';
// import 'home_page.dart';
// import 'myprofile.dart';
//
//
//
//   int _selectedIndex = 0;
//    const List<Widget> _widgetOptions = <Widget>[
//     HomeScreen(),
//     CategoriesScreen(), // Center(child: Text("Nothing here for now | Categories")), // Categories
//     SearchScreen(),// Center(child: Text("Nothing here for now | Offers")), // Offers
//     MyProfileScreen(),// Center(child: Text("Nothing here for now | My Profile")), // My Profile
//     CartScreen()
//   ];
//
//
//
//   void _onItemTapped(int index) {
//     // setState(() {
//     //   _selectedIndex = index;
//     // });
//   }
//
//
//       // BottomNavigationBar(
//       //   type: BottomNavigationBarType.fixed,
//       //   items: const <BottomNavigationBarItem>[
//       //     BottomNavigationBarItem(
//       //       icon: Icon(Icons.home),
//       //       label: 'Home',
//       //     ),
//       //     BottomNavigationBarItem(
//       //       icon: Icon(Icons.category),
//       //       label: 'Categories',
//       //     ),
//       //     BottomNavigationBarItem(
//       //       icon: Icon(Icons.discount),
//       //       label: 'Offers',
//       //     ),
//       //     BottomNavigationBarItem(
//       //       icon: Icon(Icons.account_box),
//       //       label: 'My Profile',
//       //     ),
//       //     BottomNavigationBarItem(
//       //       icon: Icon(Icons.shop),
//       //       label: 'Cart',
//       //     ),
//       //   ],
//       //   selectedIconTheme: IconThemeData(size: 25.0, color: primary()),
//       //   selectedLabelStyle: TextStyle(fontSize: 15.0, color: primary()),
//       //   unselectedIconTheme: IconThemeData(size: 25.0, color: secondary()),
//       //   unselectedLabelStyle: TextStyle(fontSize: 15.0, color: secondary()),
//       // );
//
//
//
//
// Widget bottomNavBar(){
//    return SizedBox(height: 65,);
// }
//
