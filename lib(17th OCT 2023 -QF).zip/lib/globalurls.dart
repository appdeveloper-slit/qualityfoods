
String sendOTP(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/sendOtp.php";
  return "https://qualityfoods.info/app_apis/sendOtp.php";
  // return "https://qualityfoods.info/app_apis/sendOtp.php";
}

String resendOTPUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/resendOTP.php";
  return "https://qualityfoods.info/app_apis/resendOTP.php";
  // return "https://qualityfoods.info/app_apis/resendOTP.php";
}

String verifyLoginOtpUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/verifyOTP.php";
  return "https://qualityfoods.info/app_apis/verifyOTP.php";
}

String verifyRegisterOtpUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/verifyRegisterOtp.php";
  return "https://qualityfoods.info/app_apis/verifyRegisterOtp.php";
}

String homePageDataUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/get_home_page_data.php";
  return "https://qualityfoods.info/app_apis/get_home_page_data.php";
}

String couponsDataPageUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/get_my_coupons.php";
  return "https://qualityfoods.info/app_apis/get_my_coupons.php";
}
String GMapDataPageUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/get_google_map_key.php";
  return "https://qualityfoods.info/app_apis/get_google_map_key.php";
}
String cartTime(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/get_google_map_key.php";
  return "https://qualityfoods.info/app_apis/time_service.php";
}

String getAddressDataUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/get_address.php";
  return "https://qualityfoods.info/app_apis/get_address.php";
}

String getProductDetailsUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/getProductDetails.php";
  return "https://qualityfoods.info/app_apis/getProductDetails.php";
}

String updateProfileUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/update_profile.php";
  return "https://qualityfoods.info/app_apis/update_profile.php";
}

String updateProfileMobileUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/change_mobile.php";
  return "https://qualityfoods.info/app_apis/change_mobile.php";
}

String addAdressUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/add_address.php";
  return "https://qualityfoods.info/app_apis/add_address.php";
}

String deleteAdressUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/delete_address.php";
  return "https://qualityfoods.info/app_apis/delete_address.php";
}

String updateAddressUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/update_address.php";
  return "https://qualityfoods.info/app_apis/update_address.php";
}

String getAllOrdersOddUser(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/show_user_order.php";
  return "https://qualityfoods.info/app_apis/show_user_order.php";
}

String cancelOrderUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/cancel_order.php";
  return "https://qualityfoods.info/app_apis/cancel_order.php";
}

String applyCouponUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/applyCoupon.php";
  return "https://qualityfoods.info/app_apis/applyCoupon.php";
}

String updateCartInformation(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/updateCartQty.php";
  return "https://qualityfoods.info/app_apis/updateCartQty.php";
}

String paymentOnlineAndPlaceOrder(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/placeOrderOnline.php";
  return "https://qualityfoods.info/app_apis/placeOrderOnline.php";
}

String paymentCashAndPlaceOrder(){
  // return "https://qualityfoods.info/app_apis/placeOrderOnline.php";
  /// return "https://sonibro.com/qualityfoods/html/app_apis/placeOrder.php";
  return "https://qualityfoods.info/app_apis/placeOrder.php";
}

String searchProductsUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/search.php";
  return "https://qualityfoods.info/app_apis/search.php";
}

String getMainCategoriesUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/get_categories.php";
  return "https://qualityfoods.info/app_apis/get_categories.php";
}

String getSubCategoriesUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/get_subcat_products.php";
  return "https://qualityfoods.info/app_apis/get_subcat_products.php";
}

String getNotificationsUrl(){
  //https://qualityfoods.info/app_apis/
  // return "https://sonibro.com/qualityfoods/html/app_apis/getNotifications.php";
  return "https://qualityfoods.info/app_apis/getNotifications.php";
}

String getdeletemyorderUrl(){
  // return "https://sonibro.com/qualityfoods/html/app_apis/delete_my_order.php";
  return "https://qualityfoods.info/app_apis/delete_my_order.php";
}