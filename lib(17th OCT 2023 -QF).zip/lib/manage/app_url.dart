class AppUrl {
  static String mainUrl = "https://qualityfoods.info/app_apis/";
  static String policyUrl = "https://leadstoclient.tech/privacy.php";
  static String refundPolicyUrl = "https://leadstoclient.tech/refundpolicy.php";
  static String termsUrl = "https://leadstoclient.tech/terms.php";
}
















































