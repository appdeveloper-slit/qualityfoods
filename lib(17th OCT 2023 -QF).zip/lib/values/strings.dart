class Str {
  String loremIpsum =
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.";
  String registerMessage =
      "Don't have an account ? <b><font color='#049FFF'>Sign Up</font></b>";
  String loginMessage =
      "Already have an account ? <b><font color='#049FFF'>Login</font></b>";
  String agreeTerm =
      "I Agree the <u><font color='#049FFF'>Terms &amp; Conditions</font></u> of this App";
  String resendMessage =
      "Did not receive the code ? <b><font color='#049FFF'>Resend OTP</font></b>";
  String verificationMessage =
      "A verification code is send to you<br />number provided <b><font color='#049FFF'>+91 9876543210</font></b>";

  String invalidName = "Please enter a valid name";
  String invalidMobile = "Please enter a valid number";
  String invalidAmount = "Please enter amount";
  String invalidEmail = "Please enter a valid email";
  String invalidUsername = "Please enter a valid username";
  String invalidPassword = "Enter minimum six digit password";
  String invalidConfirmPassword = "Password not match";
  String invalidOtp = "Please enter four digit OTP";
  String invalidEmpty = "This field is required";
  String invalidAccount = "Please enter a valid a/c number";
  String invalidCode = "Please enter a valid code";
  String passwordNotMatch = "Password not match";
  String invalidAadhaar = "Please enter a valid aadhar number";
  String invalidPan = "Please enter a valid pan number";
  String invalidDob = "Please select date";

  String sendingOtp = "Sending OTP …";
  String verifying = "Verifying …";
  String uploading = "Uploading …";
  String loading = "Loading …";
  String updating = "Updating …";
  String processing = "Processing …";
  String submitting = "Submitting …";
  String deleting = "Deleting …";
  String searching = "Searching …";
  String aboutUs = "Metro Bharat- National Level Hindi News, LIVE TV, Latest News and Breaking Metro Bharat is the new benchmark application in the world of News in which you can easily get news from local level to many others fields like, Politics, crime, social, business and also from Bollywood.. Metro Bharat have its own professional team of reporters who cover actual ground reporting and deliver news with more accuracy. At a same time a complete team of desk reporter, video editors and highly qualified anchors who provide you every news with proper explanation";
}
